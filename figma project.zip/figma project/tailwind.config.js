module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {

    fontFamily:{
      body:['Plus Jakarta Sans', 'sans-serif']
    },
    
    extend: {},
  },
  plugins: [],
}

